../../../../../tools/Orchestrator/orchestratorExplicit.py ../src/main/res/layout/activity_main.xml mainActivitySpecs.txt ../src/main/java/master/project/meets/MainActivity.java --gameOutputFile game.txt

